# CODEX FINAL ACCEPTANCE CHECKLIST

The final judge must mark each item PASS / FAIL / GATED / NOT VERIFIED with evidence.

## Quant correctness
- [ ] immutable first-seen per episode
- [ ] new post-resolution/invalidation episode gets new event ID
- [ ] PIT availability semantics enforced
- [ ] no random train/test split
- [ ] WFO label maturity enforced
- [ ] overlapping cohorts do not leak labels
- [ ] benchmark/sector start and end availability correct
- [ ] missing alpha remains unknown
- [ ] holiday/weekend horizon mapping correct
- [ ] outcome scheduler cannot starve events
- [ ] continuous outcomes stored before categorical labels
- [ ] economic capture mandatory for numeric total score
- [ ] narrative-only beneficiary penalized/gated
- [ ] missing valuation evidence does not create invented fair value
- [ ] missing macro/credit/risk cannot look benign
- [ ] market-specific readiness caps action
- [ ] leverage/options expression gated independently
- [ ] prospective baselines frozen before outcomes
- [ ] missed-runner reconstruction avoids hindsight leakage
- [ ] runner-recall denominator is prospective/defensible
- [ ] sample-size shrinkage prevents false high confidence
- [ ] evidence-family dedupe/independence enforced
- [ ] no unsupported alpha-superiority claim

## Product shell
- [ ] one design system on all routes
- [ ] no exposed legacy Decision Desk
- [ ] no legacy sidebar control system
- [ ] no second legacy macro stylesheet/UI generation
- [ ] top nav actually works
- [ ] active nav persists through reruns
- [ ] stable deep links work
- [ ] search works
- [ ] market filter works
- [ ] refresh does not reset route

## Control Room
- [ ] dense useful hierarchy
- [ ] macro/risk state visible
- [ ] lifecycle counts visible
- [ ] strongest new/improving/deteriorating thesis visible
- [ ] top cluster / best expression visible
- [ ] important data gates visible
- [ ] no giant raw generic table dominates

## Opportunities
- [ ] ranked list usable
- [ ] selection changes detail
- [ ] causal chain visible
- [ ] economic capture visible
- [ ] expectation state visible
- [ ] catalyst/invalidation visible
- [ ] first-seen memory visible
- [ ] outcome memory honest about immature horizons
- [ ] component score availability visible

## Verticals
- [ ] On-chain unified
- [ ] Crypto unified
- [ ] US Stocks unified
- [ ] IHSG unified
- [ ] FX unified
- [ ] Commodities unified
- [ ] market-specific missing-core evidence visible

## Macro & Events
- [ ] same visual language
- [ ] growth/inflation/rates/liquidity/credit/risk visible
- [ ] missing critical risk data fails closed
- [ ] event transmission paths usable

## Learning / Replay
- [ ] Pattern Expectancy unified
- [ ] Walk-Forward unified
- [ ] Baselines unified
- [ ] Failures unified
- [ ] Missed Winners unified
- [ ] Runner Recall visible when definable
- [ ] no fabricated sample/performance

## Browser/runtime proof
- [ ] Streamlit launched successfully
- [ ] CONTROL ROOM browser screenshot
- [ ] OPPORTUNITIES browser screenshot
- [ ] VERTICALS browser screenshot
- [ ] MACRO & EVENTS browser screenshot
- [ ] LEARNING / REPLAY browser screenshot
- [ ] navigation interaction verified
- [ ] no Streamlit runtime traceback on any route
- [ ] no dead overlay/control issue

## Repository cleanup
- [ ] caches/runtime state removed/ignored
- [ ] old release ZIPs not tracked
- [ ] stale duplicate audit/version docs consolidated
- [ ] obsolete UI implementation removed if unreachable/unneeded
- [ ] largest tracked files reviewed
- [ ] no secrets tracked
- [ ] `.gitignore` hardened
- [ ] no Git-history rewrite performed

## Exact release
- [ ] final local ZIP created
- [ ] ZIP integrity passes
- [ ] exact ZIP extracted fresh
- [ ] compile passes from extracted copy
- [ ] full tests pass from extracted copy
- [ ] no runtime state/secrets packaged
- [ ] SHA256 generated

## Git delivery
- [ ] only intentional final repository state staged
- [ ] staged diff check passes
- [ ] commit created
- [ ] push to existing `origin` branch succeeds
- [ ] local HEAD equals `origin/<branch>` after push
