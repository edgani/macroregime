# Content and social engine playbook

## Goal

Build a content system that creates discovery, authority, trust, and monetization instead of random posts.

## Content roles

Separate content into:
- discovery content
- authority content
- trust content
- conversion content

Do not rely on one type only.

## Content pillars

Build pillars around:
- recurring audience problems
- recurring audience desires
- expertise zones
- worldview/edge
- proof/case studies
- monetization bridge topics

## Series logic

Prefer repeatable series over disconnected ideas when possible.
Series create:
- recognizability
- expectation
- easier ideation
- stronger positioning

## Packaging engine

For each idea, design:
- angle
- hook
- frame
- title
- thumbnail or visual idea where relevant
- opening beat
- proof beat
- tension / curiosity beat
- payoff
- CTA or next-step logic

## Platform adaptation

### Short-form
Best for:
- discovery
- sharp takes
- fast education
- narrative tension
- pattern interrupts
- repeatable hooks

### Long-form
Best for:
- authority
- depth
- trust
- nuanced explanation
- higher-intent audience building

### Social posts / threads / carousels
Best for:
- clarity
- insight compression
- shareability
- idea ownership
- community conversations

## Content operating system

Build:
- pillar map
- series map
- idea backlog
- hook bank
- repurposing map
- testing plan
- analytics review loop

Do not just list content ideas.
Build the engine.

## Diagnostics

When content underperforms, separate:
- weak topic
- weak packaging
- weak opening
- weak retention
- weak platform fit
- weak audience-product fit
- weak consistency or distribution
