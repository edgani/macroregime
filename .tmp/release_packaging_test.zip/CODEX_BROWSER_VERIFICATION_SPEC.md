# CODEX BROWSER / RUNTIME VERIFICATION SPEC

Static grep/source inspection is not enough.

## Required runtime routes
The final Streamlit app must expose stable deep-link query values for:
- `CONTROL_ROOM`
- `OPPORTUNITIES`
- `VERTICALS`
- `MACRO_EVENTS`
- `LEARNING_REPLAY`

The visible button navigation must remain the normal product interaction. Deep links exist to make runtime verification deterministic.

## Required evidence
For every route:
- actual Streamlit server running
- actual Chromium/Edge/Chrome render
- screenshot after render settles
- DOM dump or equivalent runtime page evidence
- unique route heading visible
- no Streamlit traceback/error page

Navigation interaction must additionally be tested using either:
1. actual browser click automation, OR
2. Streamlit `AppTest` button interaction that proves all top-level buttons change/persist route state, combined with real browser rendering of all five routes.

If browser automation libraries are unavailable, do NOT abandon verification. Use installed Chrome/Edge headless mode for route screenshots and Streamlit AppTest for click-state verification.

## Runtime quality checks
Verify:
- no dead controls
- no invisible overlay blocking navigation
- active route state correct
- auto-refresh does not bounce route back
- search/filter/refresh render and do not crash
- no mixed legacy page exposed
- desktop layout at ~1720x1000 is usable

Browser evidence is generated locally and should normally be excluded from Git commits.
