# CODEX REPOSITORY CLEANUP SPEC

Target: `C:\Users\Edward\Documents\github\macroregime`

The user wants the repository clean, not a pile of old versions and generated junk.

## Safety rule
Do NOT rewrite Git history, run `git filter-repo`, force-push, reset user work, or delete uncertain source/data merely to reduce size.

Before deleting a tracked file, verify whether it is referenced by:
- Python imports
- Path/file reads
- tests
- Streamlit runtime
- deployment scripts
- documentation links
- CI/config

If uncertain and potentially required, keep it and document why.

## Delete / ignore when safe
Remove generated or obsolete material such as:
- `__pycache__/`, `*.pyc`, `.pytest_cache/`, `.mypy_cache/`, `.ruff_cache/`
- temporary test state, SQLite runtime state, transient caches
- old local logs and Codex run logs
- browser screenshot artifacts generated only for verification
- duplicate old release ZIPs / SHA files inside the source repo
- temporary extracted release directories
- stale backup files (`*.bak`, `*.tmp`, `*~`) when not intentionally used
- duplicate version-specific audit/release docs after consolidating useful information
- abandoned UI preview files if no longer used by product or docs
- stale generated reports that duplicate the maintained audit/changelog

## `.gitignore`
Ensure it prevents future repository clutter. Include appropriate entries for:
- Python caches
- virtualenvs
- runtime state / SQLite DBs
- generated browser evidence / Codex run folders
- local release ZIPs
- `.env`
- real Streamlit secrets (`.streamlit/secrets.toml`) while allowing a safe example template
- OS/editor junk

Never ignore required source/data files just to hide problems.

## Documentation consolidation
Prefer a small maintained set:
- README.md
- ARCHITECTURE.md
- LOGIC_AUDIT.md
- KNOWN_LIMITATIONS.md
- CHANGELOG.md
- TEST_MATRIX.md
- DEPLOY/RUN guide only if it adds value

Migrate useful content from stale files before deleting them. Git history preserves prior versions.

## Large-file audit
Run a current-tree size audit and list the largest tracked files. Remove only files proven unnecessary.

Do NOT rewrite history automatically. If historical Git objects are still large after current-tree cleanup, report that separately as a future optional history-cleanup task.

## Final cleanup checks
- `git status` should contain only intentional source/docs/config changes before commit.
- no secrets
- no runtime DB/state
- no generated test caches
- no old release archives tracked
- no duplicated legacy UI implementation left reachable
