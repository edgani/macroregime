# CODEX MASTER SPEC — MACROREGIME FULL REPAIR / CLEANUP / VERIFY / PUSH

## Binding repository
Work ONLY in the existing GitHub Desktop repository:

`C:\Users\Edward\Documents\github\macroregime`

Do not clone another copy and do not make a replacement project. Modify the existing repository in place.

Read these files in full before editing:
- `ORIGINAL_REQUIREMENTS.txt`
- `CODEX_MASTER_SPEC.md`
- `CODEX_ACCEPTANCE_CHECKLIST.md`
- `CODEX_REPO_CLEANUP_SPEC.md`
- `CODEX_BROWSER_VERIFICATION_SPEC.md`

Also inspect all current source, tests, docs, data adapters, screenshots in `codex_refs`, and the current Git history/status.

## Mission
Repair the repository until it is a coherent, usable, evidence-safe **Macro + Cross-Asset Opportunity Intelligence Engine** and one consistent product visually.

Do not trust prior PASS counts, version labels, audit reports, or claims. Reproduce behavior and verify independently.

If current behavior is wrong, repair it. Do not merely write a report.

---

## 1. Product objective
The engine must answer in this order:
1. WHAT changed?
2. WHY does the change matter economically?
3. WHO captures the economics?
4. HOW is revenue/margin/cash-flow captured?
5. WHAT bottleneck/scarcity matters?
6. WHAT is already priced?
7. WHAT catalyst can resolve the gap?
8. HOW asymmetric is the opportunity?
9. WHEN was it first observable/detected?
10. WHAT happened after genuinely comparable point-in-time setups?

Optimize for FEW, EARLY, HIGH-CONVICTION, EXPLAINABLE, ROBUST opportunities. Not a momentum leaderboard.

No autotrading. No private keys. No broker execution. No classic RSI/MACD/stochastic/MA-cross stack as primary logic.

---

## 2. Supported markets
Preserve market-specific logic for:
- US equities
- IHSG
- Hong Kong
- China
- Europe
- Taiwan
- Crypto
- FX
- Commodities
- Equity indices
- ETF/options/leverage only where the underlying thesis and instrument data justify it

Never force identical evidence assumptions across asset classes.

---

## 3. Quant / logic correctness — mandatory
Audit and repair all of the following. Add regression tests for every defect found.

### Point-in-time / leakage
- Immutable first-seen timestamp and price per opportunity episode.
- New episode after INVALIDATED/RESOLVED gets a new event ID.
- No future analyst revision, future sector membership, future catalyst, future market cap, future peak, or today's restated knowledge in historical signal state.
- Daily bars have explicit availability timestamps; do not pretend a close was known before market close.
- Weekend/holiday horizons map to the first observable market bar after the target horizon.
- Benchmark and sector start/end observations must be known at the appropriate times.
- Missing benchmark/sector data remains UNKNOWN and cannot silently become zero/loss.

### Walk-forward / calibration
- Chronological only. Never random shuffle financial history.
- A training outcome may enter a walk-forward fold only after the full label is mature/observable.
- Overlapping cohorts must not leak future labels.
- Sample-size shrinkage must prevent strong confidence from tiny N.
- Regime, market, asset-class and sector conditioning must not create false precision.
- Production weights cannot self-modify from recent wins.

### Outcomes
- Forward outcomes where relevant: +1D, +3D, +1W, +2W, +1M, +3M, +6M, +12M.
- Absolute, benchmark-relative, sector-relative, MFE, MAE, time-to-MFE/MAE, peak return, max drawdown and time-to-peak must use correct clocks.
- Outcome scheduler must not starve newer events.
- Success definitions remain continuous first; barrier labels are derived later.

### Economic causality
A numerical total opportunity score is forbidden if mandatory economic-capture evidence is missing.

Explicitly separate:
DRIVER → FIRST_ORDER_EFFECT → SECOND_ORDER_EFFECT → BOTTLENECK → BENEFICIARY → REVENUE_LINK → MARGIN_LINK → CATALYST → INVALIDATION.

Narrative exposure is not economic capture. Generic AI/crypto/commodity exposure cannot receive a high score without evidence of capture.

### Expectations / valuation
- Business quality is not the same as expectation gap.
- Do not invent valuation ranges or scenario dispersion from arbitrary defaults.
- If required independent valuation inputs are missing, mark valuation GATED/UNKNOWN.
- Options expression quality must remain separate from underlying thesis quality.

### Market-specific readiness
Missing required evidence caps action.
- READY may permit stronger research action.
- PARTIAL cannot masquerade as high-conviction production-ready.
- GATED remains WATCH/GATED.
- Missing macro/credit/risk data must never be interpreted as benign.

### Baselines / missed runners
- Baselines must be frozen prospectively before outcomes.
- Maintain simple comparators (strongest 6M, highest earnings growth, cheapest valid valuation, highest revisions, sector momentum, existing engine where possible).
- Missed-winner analysis must avoid hindsight leakage.
- Runner recall denominator must be defined prospectively and honestly.
- Do not claim alpha superiority until enough mature PIT/OOS evidence exists.

### Discovery / evidence quality
- Deduplicate syndicated headlines and repeated discovery queries.
- Stale/undated evidence cannot boost current evidence counts.
- Evidence families must be independent; one provider/family cannot masquerade as several confirmations.
- Automatic universe discovery must not create survivorship claims it cannot support.

### IHSG / crypto / FX / commodities
- IHSG broker/transaction accounting must use coherent denominators and distinguish negotiated/crossing contamination.
- Crypto must not infer holder capture, supply scarcity, leverage quality, or real usage from price alone.
- FX must use relative policy/macro/external-balance/positioning evidence where available.
- Commodities must use physical supply/demand/inventory/curve/capacity evidence where available.

If a feature is unavailable, say UNAVAILABLE/GATED. Never fabricate.

---

## 4. UI / UX — one design system, old UI removed
Reference:
- `codex_refs/TARGET_UI_REFERENCE.png` = primary design-language target.
- `codex_refs/CURRENT_*.png` = examples of what is still wrong/mixed.

Required visual language:
- dark navy/black background
- restrained cyan/teal accent
- subtle borders
- dense but readable terminal/control-room hierarchy
- compact typography
- small status pills
- integrated lists/tables, not default-white/raw Streamlit blocks
- consistent spacing/radius/border treatment on every route
- no old macro stylesheet, no old sidebar generation, no legacy Decision Desk surface
- no mixed generations of UI in one session

Absolute rule: if a surface is old, replace it or remove it. Do not keep old and new versions side-by-side.

Top-level routes only:
1. CONTROL ROOM
2. OPPORTUNITIES
3. VERTICALS
4. MACRO & EVENTS
5. LEARNING / REPLAY

Navigation must:
- be actually clickable
- persist through reruns
- not be blocked/reset by auto-refresh
- support stable deep links/query-param routing for runtime verification
- have obvious active state

Global controls (market filter, search, refresh, data state) belong in the same shell. No second legacy sidebar.

### CONTROL ROOM
Show macro/risk context, state counts, strongest new change, improving/deteriorating thesis, top cluster/best expression and important gates. Avoid giant raw data dumps.

### OPPORTUNITIES
Desktop target: left ranked opportunities, center selected detail, right memory/expectations/risk/catalyst, lower lifecycle/outcome/theme comparison.

### VERTICALS
One unified selector and design across On-chain, Crypto, US Stocks, IHSG, Forex, Commodities. Show only market-relevant evidence families and missing-core gates.

### MACRO & EVENTS
Same visual system. Show growth/inflation/rates/liquidity/credit/risk, crash overlay, events/transmission, market-specific implications. Missing critical risk data fails closed.

### LEARNING / REPLAY
Unified Pattern Expectancy, Walk-Forward, Baselines, Failures, Missed Winners, Runner Recall. No fabricated sample/performance.

---

## 5. Repository cleanup
Follow `CODEX_REPO_CLEANUP_SPEC.md` exactly.

Goal: make the GitHub repository materially cleaner and lighter WITHOUT deleting needed runtime/test/data files and WITHOUT rewriting Git history.

Use reference-aware deletion: search imports, file reads, tests, docs and deployment scripts before deleting anything uncertain.

---

## 6. Browser/runtime verification
Follow `CODEX_BROWSER_VERIFICATION_SPEC.md`.

A static source audit is insufficient. All five top-level routes must render in the actual Streamlit runtime, and navigation interaction must be tested.

---

## 7. Release truthfulness
Do not claim:
- production alpha proven
- OOS superiority proven
- full PIT coverage
- full survivorship-safe history
unless direct evidence exists.

A release may be called logic-verified / runtime-verified if correctness tests and runtime evidence pass, while still documenting data/research gates.

---

## 8. Final deliverables in repository
Keep the final repo concise. Preferred maintained docs:
- `README.md`
- `ARCHITECTURE.md`
- `LOGIC_AUDIT.md`
- `KNOWN_LIMITATIONS.md`
- `CHANGELOG.md`
- `TEST_MATRIX.md`
- deployment/run instructions if separate and genuinely useful

Consolidate or delete stale version-specific duplicate docs after migrating still-useful information.

The final release ZIP is a local verification artifact; it does NOT need to be committed to GitHub. Generated browser screenshots/logs also should not be committed unless explicitly required by product documentation.

---

## 9. Definition of done
Do not declare done until:
- all fixable Critical/High issues are repaired
- all regression/adversarial tests pass
- all five routes render in runtime browser evidence
- navigation interaction passes
- one visual system is exposed
- repository cleanup is complete and reference-safe
- no secrets/runtime state/cache/build junk are tracked
- exact release ZIP is created, extracted fresh, compiled and retested
- SHA256 is generated
- final independent judge returns PASS

Do not weaken tests or redefine requirements to manufacture PASS.
