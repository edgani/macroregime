# Product research and product analysis playbook

## Goal

Decide whether a product deserves to be sold, how it should be positioned, who it is for first, and what would make it easier or harder to sell.

## Research lenses

### 1. Demand quality
Check:
- is the problem painful, urgent, frequent, expensive, or status-linked?
- is the desire strong enough to act on?
- is this need evergreen, cyclical, trend-driven, or fragile?
- is the buyer already spending money to solve it?

### 2. Audience-job fit
Identify:
- functional job
- emotional job
- social/status job
- what “better” means to the buyer
- what switching cost exists

### 3. Category and alternative map
Map:
- direct competitors
- indirect substitutes
- status quo behavior
- DIY solutions
- free alternatives
- “do nothing” as an alternative

### 4. Differentiation quality
Ask:
- what is actually different?
- is it meaningful or decorative?
- is it easier, faster, safer, cheaper, more trusted, more prestigious, more fun, more certain, more specific, or more convenient?
- would the buyer notice the difference quickly?

### 5. Trust burden
How much proof is needed before purchase?
- low trust burden: simple, cheap, obvious products
- medium trust burden: expertise-based products or products with mild risk
- high trust burden: high-ticket, identity-linked, health/finance-sensitive, or unfamiliar offers

Higher trust burden means stronger proof, clearer positioning, and tighter audience targeting are needed.

### 6. Channel fit
Check:
- can this product be sold through short-form content?
- does it require education?
- does it require one-to-one trust building?
- is search intent stronger than passive discovery?
- is email/community/DM/call needed?

### 7. Pricing logic
Assess:
- willingness to pay
- perceived value
- comparison anchor
- risk reversal needs
- bundling/unbundling opportunities
- low-ticket vs high-ticket implications

### 8. Offer strength
A decent product can still be a weak offer.
Assess:
- clarity
- promise
- specificity
- proof
- urgency
- risk reduction
- ease of action
- bonus / bundle value if relevant

## Diagnostic outputs

For any product, try to answer:
- should this be sold at all?
- to whom first?
- with what angle?
- on what channel?
- at what trust level?
- with what proof?
- with what likely objections?
- with what GTM risk?

## Useful product verdicts

Use one of these when appropriate:
- strong product, weak positioning
- strong product, wrong audience
- strong product, wrong channel
- decent product, weak offer
- weak product, heavy selling burden
- niche but monetizable
- broad appeal but low differentiation
- trust-heavy product requiring proof stack
- creator-led product with authority dependency
