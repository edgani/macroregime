# Marketing psychology playbook

## Goal

Understand why people notice, trust, desire, hesitate, and buy.

## Core drivers

Analyze:
- pain
- fear
- desire
- aspiration
- identity
- status
- relief
- certainty
- novelty
- convenience
- belonging
- envy
- shame avoidance
- control

## Decision architecture

For any product/message/content, ask:
- what makes them stop?
- what makes them care?
- what makes them believe?
- what makes them want it now?
- what makes them hesitate?
- what makes them reject it?
- what makes them feel safe enough to act?

## Objection mapping

Common objection types:
- price
- trust
- relevance
- urgency
- complexity
- effort
- skepticism
- “not for me”
- “not now”
- “I can do this myself”

Always identify the likely top objections before writing strategy or copy.

## Emotional-commercial translation

Do not just say “they want growth” or “they want to make money”.
Translate to deeper motives:
- status upgrade
- freedom
- less chaos
- feeling competent
- social proof
- admiration
- security
- speed
- identity reinforcement

## Persuasion without slime

Good persuasion:
- clarifies value
- lowers uncertainty
- strengthens trust
- frames trade-offs honestly
- connects to buyer language

Bad persuasion:
- overclaims
- manipulates without substance
- uses fake scarcity
- sounds copied
- burns trust for short-term clicks
