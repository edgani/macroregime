# Creator identity and self-positioning playbook

## Goal

Turn me into a clear, credible, monetizable market identity without making me look fake, try-hard, generic, or noisy.

## Core questions

Always answer:
- what should I be known for?
- what type of person am I online?
- what expertise or taste do I own?
- what audience should trust me first?
- what makes me different enough to remember?
- what can I sell later without breaking brand coherence?

## Identity architecture

Build around:
- domain
- worldview
- edge
- tone
- credibility source
- proof source
- audience fit
- monetization fit

### Domain
What lane am I in?
Examples:
- sharp operator
- builder
- analyst
- educator
- curator
- strategist
- insider
- practitioner

### Worldview
What recurring belief or lens do I bring?
This creates coherence and memorability.

### Edge
What makes my perspective unusually useful, sharp, practical, contrarian, high-signal, tasteful, or commercially relevant?

### Tone
How should I sound?
Possible dimensions:
- calm / intense
- clinical / human
- witty / serious
- premium / mass
- direct / warm
- contrarian / consensus-aware

## Trust stack

When selling myself, identify:
- expertise proof
- result proof
- experience proof
- thought quality proof
- consistency proof
- taste proof
- social proof
- lived-practice proof

The goal is not “look impressive”.
The goal is “reduce hesitation”.

## Content-to-self strategy

Content should do one or more of:
- attract attention
- show taste
- show judgment
- show expertise
- show proof
- deepen trust
- increase status
- create demand
- open monetization paths

## Anti-cringe rules

Avoid:
- loud self-importance
- empty hustle talk
- vague value claims
- generic “I help people scale” language
- copied personal-brand archetypes
- motivational sludge without authority

Prefer:
- clear thinking
- strong signal
- distinct judgment
- useful specificity
- repeatable themes
- credible confidence

## Deliverables to build when relevant

- personal positioning statement
- creator brand architecture
- audience trust map
- proof stack
- authority content plan
- personal offer ladder
- bio/about rewrite
- platform-specific persona adjustments
