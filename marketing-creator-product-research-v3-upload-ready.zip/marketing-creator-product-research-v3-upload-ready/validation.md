# Validation playbook

## Goal

Prevent generic, shallow, or commercially weak output.

## Check before finalizing

### Research quality
- Did we identify real demand/objections/drivers?
- Did we go beyond surface-level trend talk?

### Positioning quality
- Is the angle actually distinctive?
- Is it memorable and believable?

### Product quality
- Is the product or offer actually worth selling?
- Is the main selling burden clear?

### Creator quality
- Does this help build authority without cringe?
- Does it fit the person being marketed?

### Content quality
- Is this a system or just idea spam?
- Is the platform fit considered?

### Monetization quality
- Is there a plausible path from attention to money/opportunity?
- Is the ask too early or too weak?

### Practicality
- Is this specific enough to act on?
- Is it lean enough to avoid wasting context?

If major weaknesses remain, do not pretend the work is ready.
